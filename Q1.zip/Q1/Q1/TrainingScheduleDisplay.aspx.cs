﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data; // add refernces
using System.Data.SqlClient; // add refernces
using System.Configuration; // add refernces

namespace Q1
{
    public partial class TrainingScheduleDisplay : System.Web.UI.Page
    {
        //to display the training schedule
        protected void Page_Load(object sender, EventArgs e)
        {
            //establishing the connection
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            //declaring the command
            SqlCommand cmd = new SqlCommand("Select * from Bindhu.TrainingSchedule", con);
            con.Open();
            //declaring the data reader
            SqlDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            if (dr.HasRows)
                dt.Load(dr);
            con.Close();
            if (dt.Rows.Count > 0)
            {
                gvTraining.DataSource = dt;
                gvTraining.DataBind();
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Training Schedule not available');</SCRIPT>");

        }
    }
}
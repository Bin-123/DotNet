﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data; //add references
using System.Data.SqlClient; //add references
using System.Configuration; //add references

namespace Q1
{
    public partial class TrainingScheduleAdd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //to add the schedule
        protected void btnAddSchedule_Click(object sender, EventArgs e)
        {
            //establishing the connection
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            //declaring the command
            SqlCommand cmd = new SqlCommand("INSERT INTO Bindhu.TrainingSchedule (TrainerName, CourseName, StartDate, EndDate, Company, Location) VALUES(@TName, @CName, @SDate, @EDate, @Com, @Loc)", con);
            //inserting the parameters
            cmd.Parameters.AddWithValue("@TName", txtTrainerName.Text);
            cmd.Parameters.AddWithValue("@CName", txtCourseName.Text);           
            cmd.Parameters.AddWithValue("@SDate", Convert.ToDateTime(txtStartDate.Text));
            cmd.Parameters.AddWithValue("@EDate", Convert.ToDateTime(txtEndDate.Text));
            cmd.Parameters.AddWithValue("@Com", txtCompany.Text);
            cmd.Parameters.AddWithValue("@Loc", txtLocation.Text);

            con.Open();
            int recordsAffected = cmd.ExecuteNonQuery();
            con.Close();

            if (recordsAffected > 0)
            {
                Response.Write("<SCRIPT type='text/javascript'>alert('Training Schedule inserted successfully');</SCRIPT>");
            }
            else
                Response.Write("<SCRIPT type='text/javascript'>alert('Training Schedule not inserted');</SCRIPT>");

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab9
{
    public partial class PostbackDemo : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.IsPostBack == false)
            {
                //Add Items to Dropdown
                dnservicelist.Items.Add("Airtel");
                dnservicelist.Items.Add("Vodafone");
                //Different Text and Value 
                dnservicelist.Items.Add(new ListItem("BPL", "Loop"));
            }

        }

        protected void dnservicelist_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtservice.Text = dnservicelist.SelectedValue;
            Trace.Write("user selected " + dnservicelist.SelectedValue);
            Trace.Warn("user selected " + dnservicelist.SelectedValue);

        }

        protected void Btnwelcome_Click(object sender, EventArgs e)
        {
            Response.Write("<SCRIPT type='text/javaScript'>alert('Welcome to Asp.net');</SCRIPT>");

        }
    }
}
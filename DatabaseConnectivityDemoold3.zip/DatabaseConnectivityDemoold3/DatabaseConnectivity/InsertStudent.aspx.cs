﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DatabaseConnectivity
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con=new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);
            SqlCommand cmd = new SqlCommand("insert into Student_Master(Stud_Code,Stud_Name,Dept_Code,Stud_Dob,Address) Values (@SCode,@SName,@DCode,@DOB,@Address)",con);
            cmd.Parameters.AddWithValue("@SCode", txtcode.Text);
            cmd.Parameters.AddWithValue("@SName", txtname.Text);
            cmd.Parameters.AddWithValue("@DCode", txtdcode.Text);
            cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(txtdob.Text));
            cmd.Parameters.AddWithValue("@Address", txtaddr.Text);

            con.Open();
            int recordsaffected = cmd.ExecuteNonQuery();
            con.Close();
            if (recordsaffected > 0)
            {
                Response.Write("<SCRIPT type='text/javaScript'>alert('Student Data inserted successfully');</SCRIPT>");
            }
            else
                Response.Write("<SCRIPT type='text/javaScript'>alert('Student Data not inserted');</SCRIPT>");
        }
    }
}